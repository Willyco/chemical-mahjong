"""
化学麻将 - 持久化游戏状态
Chemical Mahjong - Persistent Game State
"""

import sys
sys.path.insert(0, '/Users/yehonghao/.qclaw/workspace/chemical_mahjong')

from auto_complete import AutoMahjongGame
from game import CardType
import json

# 全局游戏状态
game_state = None

def init_game():
    """初始化游戏"""
    global game_state
    game_state = AutoMahjongGame(num_players=4)
    game_state.start_game()
    return game_state

def get_game():
    """获取当前游戏状态"""
    global game_state
    if game_state is None:
        init_game()
    return game_state

def show_player_hand(player_id):
    """显示玩家手牌"""
    game = get_game()
    hand = game.players[player_id]
    valence = sum(card.valence for card in hand)
    
    print(f"\n【玩家{player_id + 1}的手牌】")
    print(f"总牌数：{len(hand)}张")
    print(f"化合价总和：{valence}")
    
    by_type = {}
    for card in hand:
        if card.card_type not in by_type:
            by_type[card.card_type] = []
        by_type[card.card_type].append(card)
    
    print(f"\n按类型分类：")
    for card_type in CardType:
        if card_type in by_type:
            cards_str = " ".join(str(c) for c in by_type[card_type])
            print(f"  {card_type.value}：{cards_str}")
    
    print(f"\n完整列表：")
    print(f"  {' '.join(str(c) for c in hand)}")

def player_discard(player_id, card_name):
    """玩家出牌"""
    game = get_game()
    hand = game.players[player_id]
    
    # 找到要出的牌
    discard_card = None
    for card in hand:
        if str(card) == card_name:
            discard_card = card
            break
    
    if discard_card is None:
        print(f"❌ 找不到牌：{card_name}")
        return False
    
    hand.remove(discard_card)
    game.discard_pile.append(discard_card)
    
    print(f"\n你出牌：{discard_card}")
    print(f"你的手牌数：{len(hand)}张")
    print(f"你的化合价：{sum(card.valence for card in hand)}")
    
    # 检查其他玩家是否可以吃碰
    print(f"\n其他玩家反应：")
    has_action = False
    for check_idx in range(1, 4):
        check_player_id = check_idx
        eat_peng = game.get_eat_peng_suggestions(check_player_id, discard_card, discard_player_id=0)
        
        if eat_peng['can_eat']:
            print(f"  玩家{check_player_id + 1}可以吃！")
            has_action = True
            break
        elif eat_peng['can_peng']:
            print(f"  玩家{check_player_id + 1}可以碰！")
            has_action = True
            break
    
    if not has_action:
        print(f"  无人吃碰")
    
    return True

def other_players_turn():
    """其他三家的回合"""
    game = get_game()
    
    print("\n" + "-" * 80)
    print("【其他三家的回合】")
    print("-" * 80)
    
    for player_id in range(1, 4):
        # 摸牌
        if len(game.deck.cards) > 0:
            drawn_card = game.deck.draw(1)[0]
            game.players[player_id].append(drawn_card)
            print(f"\n玩家{player_id + 1}摸牌：{drawn_card}")
        
        # 出牌
        suggestion = game.get_ai_suggestion(player_id)
        if suggestion['suggestions']:
            discard_card = suggestion['suggestions'][0]['card']
            print(f"玩家{player_id + 1}出牌：{discard_card}")
            
            game.players[player_id].remove(discard_card)
            game.discard_pile.append(discard_card)
            
            # 检查是否有人吃碰
            has_action = False
            for check_idx in range(1, 4):
                check_player_id = (player_id + check_idx) % 4
                eat_peng = game.get_eat_peng_suggestions(check_player_id, discard_card, discard_player_id=player_id)
                
                if eat_peng['can_eat']:
                    print(f"  → 玩家{check_player_id + 1}可以吃")
                    has_action = True
                    break
                elif eat_peng['can_peng']:
                    print(f"  → 玩家{check_player_id + 1}可以碰")
                    has_action = True
                    break
            
            if not has_action:
                print(f"  → 无人吃碰")

def your_turn():
    """你的回合"""
    game = get_game()
    
    print("\n" + "=" * 80)
    print("【你的回合】")
    print("=" * 80)
    
    # 摸牌
    if len(game.deck.cards) > 0:
        drawn_card = game.deck.draw(1)[0]
        game.players[0].append(drawn_card)
        print(f"\n你摸牌：{drawn_card}")
    
    # 显示手牌
    show_player_hand(0)
    
    # 出牌建议
    print(f"\n【出牌建议】")
    suggestion = game.get_ai_suggestion(0)
    if suggestion['suggestions']:
        for i, sug in enumerate(suggestion['suggestions'][:3], 1):
            card = sug['card']
            reason = sug['reason']
            priority = sug['priority']
            print(f"  {i}. {card} (优先级{priority}/10) - {reason}")
    
    print("\n" + "=" * 80)
    print("请告诉我你要出哪张牌")
    print("=" * 80)

# 初始化
if __name__ == "__main__":
    game = init_game()
    
    print("\n" + "=" * 80)
    print("【化学麻将 - 持久化游戏】")
    print("=" * 80)
    
    print("\n【初始手牌】")
    show_player_hand(0)
    
    print("\n" + "=" * 80)
    print("请告诉我你要出哪张牌")
    print("=" * 80)
