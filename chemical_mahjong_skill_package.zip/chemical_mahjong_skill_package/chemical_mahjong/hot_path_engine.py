"""
化学麻将 - 热路预计算 AI 辅助引擎 v3
Strategy A: 在玩家回合前预计算所有出牌选项，即时响应

核心思想：把 O(n²) 的分析工作提前做，玩家出牌时只做 O(1) 查表。

v3 优化：
  - 消除14次重复的 _check_route_b + _has_waste_cards 调用
  - 改为预计算全手牌特征一次，各选项 O(1) 查表
  - 将单玩家增量重算降到 <0.05ms
"""

import sys
sys.path.insert(0, '/Users/yehonghao/.qclaw/workspace/chemical_mahjong')

from game import ChemicalMahjongGame, Card, CardType, WinChecker
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
import time


@dataclass
class DiscardOption:
    """出牌选项"""
    card: Card
    priority: int          # 1-10
    reason: str
    new_valence: int
    route_a_viable: bool
    route_b_viable: bool
    route_c_viable: bool
    combo_value: int
    immediate_win: bool   # 出牌后直接和牌
    win_after_draw: bool # 出牌后等自摸
    is_waste: bool


class HotPathEngine:
    """热路预计算引擎 - 预计算 + O(1) 查表"""

    def __init__(self, game: ChemicalMahjongGame):
        self.game = game
        self.win_checker = WinChecker()
        self._cache: Dict[int, List[DiscardOption]] = {}
        self._last_hash: Dict[int, int] = {}

    def precompute(self, player_id: int) -> List[DiscardOption]:
        """全量预计算，O(n) 时间复杂度"""
        hand = self.game.players[player_id]
        n = len(hand)
        if n == 0:
            return []

        hand_hash = hash(tuple(sorted(str(c) for c in hand)))
        if self._last_hash.get(player_id) == hand_hash:
            return self._cache.get(player_id, [])

        # ---- Step 1: 化合价 ----
        min_val, _, other_val, actual_val = self.win_checker.calculate_optimal_valence(hand)
        current_valence = min_val  # 最接近0的组合

        # ---- Step 2: 预构建查找表（一次性 O(n)）----
        name_count: Dict[str, int] = {}
        for card in hand:
            key = f"{card.name}|{card.card_type.value}"
            name_count[key] = name_count.get(key, 0) + 1

        valence_abs: Dict[int, List[Card]] = {}
        for card in hand:
            if card.valence != 0:
                k = abs(card.valence)
                if k not in valence_abs:
                    valence_abs[k] = []
                valence_abs[k].append(card)

        atomic_order = WinChecker.ELEMENT_ORDER
        atomic_to_cards: Dict[int, List[Card]] = {}
        for card in hand:
            if card.card_type == CardType.ELEMENT:
                try:
                    a = atomic_order.index(card.name)
                    if a not in atomic_to_cards:
                        atomic_to_cards[a] = []
                    atomic_to_cards[a].append(card)
                except ValueError:
                    pass

        # ---- Step 2e: 预计算全手牌特征（14个选项共用，只算一次）----
        hand_has_molecule   = any(c.card_type == CardType.MOLECULE for c in hand)
        hand_has_cond       = any(c.card_type == CardType.CONDITION for c in hand)
        hand_has_state      = any(c.card_type == CardType.STATE for c in hand)
        hand_has_reactant   = any(c.card_type in (CardType.ELEMENT, CardType.ION, CardType.MOLECULE) for c in hand)

        # ---- Step 3: 生成出牌选项 ----
        options: List[DiscardOption] = []
        for i, card in enumerate(hand):
            option = self._eval_fast(
                i, card, hand, current_valence,
                name_count, valence_abs, atomic_to_cards,
                hand_has_molecule, hand_has_cond, hand_has_state, hand_has_reactant
            )
            options.append(option)

        options.sort(key=lambda x: x.priority, reverse=True)
        self._cache[player_id] = options
        self._last_hash[player_id] = hand_hash
        return options

    def _eval_fast(
        self,
        discard_idx: int,
        card: Card,
        hand: List[Card],
        current_valence: int,
        name_count: Dict[str, int],
        valence_abs: Dict[int, List[Card]],
        atomic_to_cards: Dict[int, List[Card]],
        hand_has_molecule: bool,
        hand_has_cond: bool,
        hand_has_state: bool,
        hand_has_reactant: bool
    ) -> DiscardOption:
        """评估单张出牌（利用预计算数据，O(n) 但 n=14 常数）"""

        new_valence = current_valence - card.valence
        reasons: List[str] = []
        priority = 5
        combo_value = 0
        is_waste = False
        atomic_order = WinChecker.ELEMENT_ORDER
        n = len(hand)

        # ===== 路线可行性（用预计算特征 O(1) 判断）=====
        # 出牌后检查：被出的那张牌是否影响各路线条件
        card_is_cond   = card.card_type == CardType.CONDITION
        card_is_state  = card.card_type == CardType.STATE
        card_is_mol    = card.card_type == CardType.MOLECULE

        remaining_has_mol   = hand_has_molecule   if not card_is_mol   else any(hand[j].card_type == CardType.MOLECULE   for j in range(n) if j != discard_idx)
        remaining_has_cond  = hand_has_cond       if not card_is_cond  else any(hand[j].card_type == CardType.CONDITION  for j in range(n) if j != discard_idx)
        remaining_has_state = hand_has_state      if not card_is_state else any(hand[j].card_type == CardType.STATE     for j in range(n) if j != discard_idx)

        route_a_viable = (new_valence == 0)
        route_b_viable = bool(remaining_has_cond and remaining_has_state and
                              remaining_has_mol and hand_has_reactant)
        route_c_viable = remaining_has_mol and not remaining_has_cond and not remaining_has_state

        # ===== 废牌判断（O(1)）=====
        if card_is_cond or card_is_state:
            if not remaining_has_mol:
                is_waste = True
                reasons.append("废牌：无反应物")
                priority = 9

        # ===== 化合价调节价值 ----
        need = current_valence
        if card.valence != 0:
            if need > 0 and card.valence > 0:
                score = min(10, 3 + abs(card.valence))
                reasons.append(f"出{card}({card.valence:+})→{new_valence}")
                priority = max(priority, score)
            elif need < 0 and card.valence < 0:
                score = min(10, 3 + abs(card.valence))
                reasons.append(f"出{card}({card.valence})→{new_valence}")
                priority = max(priority, score)
            elif new_valence == 0:
                if not is_waste:
                    reasons.append(f"🎯 出{card}→和牌！")
                    priority = 10
            else:
                reasons.append(f"出{card}→{new_valence}（偏离和牌）")
                priority = max(priority, 2)
        else:
            reasons.append(f"{card.name}为分子/条件/状态牌，不影响化合价")
            priority = max(priority, 3)

        # ===== 组合价值（O(1) 查表）====
        card_key = f"{card.name}|{card.card_type.value}"

        # 成对
        if card.valence != 0:
            for other in valence_abs.get(abs(card.valence), []):
                if other != card and other.valence * card.valence < 0:
                    combo_value += 3
                    reasons.append(f"可与{other}成对")

        # 成刻子
        cnt = name_count.get(card_key, 0)
        if cnt >= 3:
            combo_value += 5
            reasons.append(f"可成{card.name}刻子")
        elif cnt == 2:
            combo_value += 2
            reasons.append(f"有{card.name}对子")

        # 成顺子（用原子序数表）
        if card.card_type == CardType.ELEMENT:
            try:
                pos = atomic_order.index(card.name)
                for a1 in range(pos - 2, pos + 3):
                    for a2 in range(a1 + 1, pos + 3):
                        if a2 == pos:
                            continue
                        if a1 < 0 or a2 < 0 or a1 >= len(atomic_order) or a2 >= len(atomic_order):
                            continue
                        positions = sorted([a1, pos, a2])
                        if positions[1] == positions[0] + 1 and positions[2] == positions[1] + 1:
                            if a1 in atomic_to_cards and pos in atomic_to_cards and a2 in atomic_to_cards:
                                combo_value += 2
                                reasons.append(f"可成顺子{atomic_order[a1]}-{atomic_order[pos]}-{atomic_order[a2]}")
            except ValueError:
                pass

        if combo_value >= 5:
            reasons.append(f"⚠️ 有{combo_value}点组合价值，建议保留")
            priority = min(priority, 2)

        immediate_win = route_a_viable and not is_waste
        win_after_draw = (new_valence == 0 and not is_waste)

        return DiscardOption(
            card=card,
            priority=priority,
            reason="；".join(reasons[:4]),
            new_valence=new_valence,
            route_a_viable=route_a_viable,
            route_b_viable=route_b_viable,
            route_c_viable=route_c_viable,
            combo_value=combo_value,
            immediate_win=immediate_win,
            win_after_draw=win_after_draw,
            is_waste=is_waste,
        )

    def get_top(self, player_id: int, top_n: int = 5) -> List[DiscardOption]:
        if player_id not in self._cache:
            self.precompute(player_id)
        return self._cache[player_id][:top_n]

    def get_best(self, player_id: int) -> Optional[DiscardOption]:
        opts = self.get_top(player_id, 1)
        return opts[0] if opts else None

    def invalidate(self, player_id: int):
        self._cache.pop(player_id, None)
        self._last_hash.pop(player_id, None)


# ============ 性能基准 ============

def benchmark():
    print("=" * 60)
    print("🔥 热路预计算引擎 v3 性能基准")
    print("=" * 60)

    # 开局预热
    t0 = time.perf_counter()
    for _ in range(100):
        g = ChemicalMahjongGame(num_players=4)
        g.start_game()
        e = HotPathEngine(g)
        for p in range(4):
            e.precompute(p)
    t1 = time.perf_counter()
    print(f"\n【开局预热 x100】{(t1-t0)*1000:.2f}ms | 平均{(t1-t0)*10:.4f}ms | {100/(t1-t0):.0f}次/秒")

    # O(1) 查询
    g = ChemicalMahjongGame(num_players=4)
    g.start_game()
    e = HotPathEngine(g)
    for p in range(4):
        e.precompute(p)

    t0 = time.perf_counter()
    for _ in range(10000):
        e.get_top(0, 5)
    t1 = time.perf_counter()
    print(f"\n【O(1)缓存查询 x10000】{(t1-t0)*1000:.4f}ms | 平均{(t1-t0)/10:.6f}ms")

    # 增量重算
    t0 = time.perf_counter()
    for _ in range(1000):
        e.invalidate(0)
        e.precompute(0)
    t1 = time.perf_counter()
    print(f"\n【单玩家增量重算 x1000】{(t1-t0)*1000:.2f}ms | 平均{(t1-t0):.4f}ms")

    # 真实游戏场景
    query_times = []
    recalc_times = []
    for _ in range(200):
        for pid in range(4):
            h = g.players[pid]
            if not h:
                continue
            discard = h[0]
            g.players[pid].remove(discard)
            g.discard_pile.append(discard)
            for p in range(4):
                if p != pid:
                    e.invalidate(p)

            if g.deck.cards:
                drawn = g.deck.draw(1)[0]
                g.players[pid].append(drawn)
                t_r0 = time.perf_counter()
                e.invalidate(pid)
                e.precompute(pid)
                recalc_times.append((time.perf_counter() - t_r0) * 1000)
                t_q0 = time.perf_counter()
                e.get_top(pid, 5)
                query_times.append((time.perf_counter() - t_q0) * 1000)

    qt = sorted(query_times)
    rt = sorted(recalc_times)
    n = len(qt)
    print(f"\n【真实游戏场景（200轮 x 4人）】")
    print(f"  O(1)查询：平均 {sum(qt)/n:.6f}ms | 最大 {max(qt):.6f}ms | P99 {qt[int(n*0.99)]:.6f}ms")
    print(f"  增量重算：平均 {sum(rt)/len(rt):.6f}ms | 最大 {max(rt):.6f}ms | P99 {rt[int(len(rt)*0.99)]:.6f}ms")

    print(f"\n✅ v3 vs v2 对比：")
    print(f"  v2 增量重算 ~0.14ms → v3 ~{sum(rt)/len(rt):.4f}ms，"
          f"提升 {0.14/(sum(rt)/len(rt)):.1f}倍")


if __name__ == "__main__":
    benchmark()
