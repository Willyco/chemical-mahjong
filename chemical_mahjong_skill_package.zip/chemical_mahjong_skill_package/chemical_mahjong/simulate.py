"""
化学麻将 - 完整游戏模拟
Chemical Mahjong - Full Game Simulation
"""

import sys
sys.path.insert(0, '/Users/yehonghao/.qclaw/workspace/chemical_mahjong')

from game import ChemicalMahjongGame, Card, CardType

def simulate_game():
    """模拟一局完整的4人麻将游戏"""
    
    game = ChemicalMahjongGame(num_players=4)
    game.start_game()
    
    print("\n" + "=" * 70)
    print("游戏开始！")
    print("=" * 70)
    
    # 显示所有玩家的初始手牌
    for i in range(4):
        print(f"\n【玩家{i + 1}的初始手牌】")
        game.show_player_hand(i)
    
    # 模拟游戏流程
    print("\n" + "=" * 70)
    print("游戏流程")
    print("=" * 70)
    
    # 第1轮：庄家(玩家1)出牌
    print("\n【第1轮】")
    print("庄家玩家1出牌...")
    game.show_ai_suggestion(0)
    
    # 庄家选择出牌（选择优先级最高的）
    suggestion = game.get_ai_suggestion(0)
    if suggestion['suggestions']:
        discard_card = suggestion['suggestions'][0]['card']
        print(f"\n玩家1选择出牌：{discard_card}")
        game.players[0].remove(discard_card)
        game.discard_pile.append(discard_card)
        
        # 检查其他玩家是否可以吃碰
        print(f"\n检查其他玩家是否可以吃碰...")
        for player_id in range(1, 4):
            eat_peng = game.get_eat_peng_suggestions(player_id, discard_card, discard_player_id=0)
            if eat_peng['can_peng'] or eat_peng['can_eat']:
                print(f"玩家{player_id + 1}可以吃碰！")
                game.show_eat_peng_suggestions(player_id, discard_card, discard_player_id=0)
            else:
                print(f"玩家{player_id + 1}无法吃碰")
    
    # 第2轮：玩家2出牌
    print("\n" + "-" * 70)
    print("【第2轮】")
    print("玩家2出牌...")
    game.show_ai_suggestion(1)
    
    suggestion = game.get_ai_suggestion(1)
    if suggestion['suggestions']:
        discard_card = suggestion['suggestions'][0]['card']
        print(f"\n玩家2选择出牌：{discard_card}")
        game.players[1].remove(discard_card)
        game.discard_pile.append(discard_card)
        
        print(f"\n检查其他玩家是否可以吃碰...")
        for player_id in [2, 3, 0]:
            eat_peng = game.get_eat_peng_suggestions(player_id, discard_card, discard_player_id=1)
            if eat_peng['can_peng'] or eat_peng['can_eat']:
                print(f"玩家{player_id + 1}可以吃碰！")
                game.show_eat_peng_suggestions(player_id, discard_card, discard_player_id=1)
            else:
                print(f"玩家{player_id + 1}无法吃碰")
    
    # 第3轮：玩家3出牌
    print("\n" + "-" * 70)
    print("【第3轮】")
    print("玩家3出牌...")
    game.show_ai_suggestion(2)
    
    suggestion = game.get_ai_suggestion(2)
    if suggestion['suggestions']:
        discard_card = suggestion['suggestions'][0]['card']
        print(f"\n玩家3选择出牌：{discard_card}")
        game.players[2].remove(discard_card)
        game.discard_pile.append(discard_card)
        
        print(f"\n检查其他玩家是否可以吃碰...")
        for player_id in [3, 0, 1]:
            eat_peng = game.get_eat_peng_suggestions(player_id, discard_card, discard_player_id=2)
            if eat_peng['can_peng'] or eat_peng['can_eat']:
                print(f"玩家{player_id + 1}可以吃碰！")
                game.show_eat_peng_suggestions(player_id, discard_card, discard_player_id=2)
            else:
                print(f"玩家{player_id + 1}无法吃碰")
    
    # 第4轮：玩家4出牌
    print("\n" + "-" * 70)
    print("【第4轮】")
    print("玩家4出牌...")
    game.show_ai_suggestion(3)
    
    suggestion = game.get_ai_suggestion(3)
    if suggestion['suggestions']:
        discard_card = suggestion['suggestions'][0]['card']
        print(f"\n玩家4选择出牌：{discard_card}")
        game.players[3].remove(discard_card)
        game.discard_pile.append(discard_card)
        
        print(f"\n检查其他玩家是否可以吃碰...")
        for player_id in [0, 1, 2]:
            eat_peng = game.get_eat_peng_suggestions(player_id, discard_card, discard_player_id=3)
            if eat_peng['can_peng'] or eat_peng['can_eat']:
                print(f"玩家{player_id + 1}可以吃碰！")
                game.show_eat_peng_suggestions(player_id, discard_card, discard_player_id=3)
            else:
                print(f"玩家{player_id + 1}无法吃碰")
    
    # 显示当前状态
    print("\n" + "=" * 70)
    print("当前游戏状态")
    print("=" * 70)
    
    print(f"\n弃牌堆（共{len(game.discard_pile)}张）：")
    discard_str = " ".join(str(c) for c in game.discard_pile)
    print(f"  {discard_str}")
    
    print(f"\n各玩家剩余手牌数：")
    for i in range(4):
        print(f"  玩家{i + 1}：{len(game.players[i])}张")
    
    print(f"\n各玩家化合价总和：")
    for i in range(4):
        valence = sum(card.valence for card in game.players[i])
        is_listening = valence == 0
        status = "✅ 已听牌" if is_listening else f"❌ 还需调整{abs(valence)}"
        print(f"  玩家{i + 1}：{valence} {status}")
    
    # 继续几轮
    print("\n" + "=" * 70)
    print("继续游戏（快速模式）")
    print("=" * 70)
    
    round_num = 5
    for round_idx in range(round_num):
        player_id = round_idx % 4
        print(f"\n【第{4 + round_idx + 1}轮】玩家{player_id + 1}出牌...")
        
        suggestion = game.get_ai_suggestion(player_id)
        if suggestion['suggestions']:
            discard_card = suggestion['suggestions'][0]['card']
            print(f"  出牌：{discard_card}（化合价{discard_card.valence}）")
            game.players[player_id].remove(discard_card)
            game.discard_pile.append(discard_card)
            
            # 检查是否有人可以吃碰
            has_action = False
            for check_player_id in range(1, 4):
                actual_player_id = (player_id + check_player_id) % 4
                eat_peng = game.get_eat_peng_suggestions(actual_player_id, discard_card, discard_player_id=player_id)
                if eat_peng['can_peng'] or eat_peng['can_eat']:
                    if eat_peng['can_eat']:
                        print(f"  → 玩家{actual_player_id + 1}吃牌！")
                        has_action = True
                    elif eat_peng['can_peng']:
                        print(f"  → 玩家{actual_player_id + 1}碰牌！")
                        has_action = True
            
            if not has_action:
                print(f"  → 无人吃碰")
    
    # 最终统计
    print("\n" + "=" * 70)
    print("游戏统计")
    print("=" * 70)
    
    print(f"\n弃牌堆（共{len(game.discard_pile)}张）：")
    discard_str = " ".join(str(c) for c in game.discard_pile)
    print(f"  {discard_str}")
    
    print(f"\n各玩家剩余手牌数：")
    for i in range(4):
        print(f"  玩家{i + 1}：{len(game.players[i])}张")
    
    print(f"\n各玩家化合价总和：")
    for i in range(4):
        valence = sum(card.valence for card in game.players[i])
        is_listening = valence == 0
        status = "✅ 已听牌" if is_listening else f"❌ 还需调整{abs(valence)}"
        print(f"  玩家{i + 1}：{valence} {status}")
    
    print("\n" + "=" * 70)
    print("游戏模拟结束")
    print("=" * 70)


if __name__ == "__main__":
    simulate_game()
