#!/usr/bin/env python3
"""化学麻将热路AI辅助 - 完整游戏演示"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

import io

# 抑制游戏引擎的启动banner
old_stdout = sys.stdout
sys.stdout = io.StringIO()

from game import ChemicalMahjongGame, CardType
from hot_path_engine import HotPathEngine

game = ChemicalMahjongGame(num_players=4)
game.start_game()
sys.stdout = old_stdout  # 恢复输出

e = HotPathEngine(game)
for p in range(4):
    e.precompute(p)


def fmt_hand(hand):
    g = {}
    for c in hand:
        g.setdefault(c.card_type, []).append(str(c))
    parts = []
    for ct in [CardType.ELEMENT, CardType.ION, CardType.MOLECULE,
               CardType.CONDITION, CardType.STATE]:
        if ct in g:
            parts.append(f"{ct.name}:{' '.join(g[ct])}")
    return " | ".join(parts)


def is_win(hand):
    v, _ = e.win_checker.calculate_optimal_valence(hand)
    has_mol = any(c.card_type == CardType.MOLECULE for c in hand)
    has_cond = any(c.card_type == CardType.CONDITION for c in hand)
    # 废牌：只有条件牌但无反应物分子
    is_waste = has_cond and not has_mol
    return v == 0 and not is_waste, v


# ===== 游戏输出 =====
print("=" * 62)
print("  🀄  化学麻将 · 热路预计算AI辅助  🀄")
print("=" * 62)

dh = game.players[0]
_, init_v = is_win(dh)
print(f"\n📋 庄家初始手牌（14张）化合价={init_v}")
print(f"   {fmt_hand(dh)}")

print("\n💡 AI建议 Top3：")
for i, o in enumerate(e.get_top(0, 3), 1):
    flag = "🎯" if o.immediate_win else ("⏳" if o.win_after_draw else "  ")
    print(f"   {i}. 出【{o.card}】→{o.new_valence} {flag}  {o.reason[:32]}")

print()
print("-" * 62)

r = 0
winner = None
dealer = 0

while r < 300 and winner is None:
    r += 1
    pid = (r - 1) % 4
    hand = game.players[pid]
    if not hand:
        continue

    v, _ = is_win(hand)
    opts = e.get_top(pid, 3)
    best = opts[0]

    game.players[pid].remove(best.card)
    game.discard_pile.append(best.card)

    for p in range(4):
        e.invalidate(p)

    # ===== 碰牌检测 =====
    peng_pid = None
    for cp in range(4):
        if cp == pid:
            continue
        ep = game.get_eat_peng_suggestions(cp, best.card, pid)
        if ep['can_peng'] and best.card in game.players[cp]:
            hc = game.players[cp]
            hc.remove(best.card)
            hc.extend(ep['peng_cards'])
            e.invalidate(cp)
            e.precompute(cp)
            peng_pid = cp
            print(f"  [R{r}] P{cp+1} 碰 {best.card}！")
            break

    if peng_pid is not None:
        if game.deck.cards:
            dr = game.deck.draw(1)[0]
            game.players[peng_pid].append(dr)
            e.invalidate(peng_pid)
            e.precompute(peng_pid)
            ok, z = is_win(game.players[peng_pid])
            if ok:
                print(f"  🎉🎉 P{peng_pid+1} 自摸！")
                winner = peng_pid
                break
        continue

    # ===== 摸牌 =====
    dealer_first = (pid == dealer and r == 1)

    if dealer_first:
        # 庄家首轮：出牌后不摸牌，直接进入下家
        print(f"[R{r}] P{pid+1}(庄) 出【{best.card}】→{v}  手牌14张")
    elif game.deck.cards:
        dr = game.deck.draw(1)[0]
        game.players[pid].append(dr)
        e.invalidate(pid)
        e.precompute(pid)
        ok, z = is_win(game.players[pid])
        flag = "🎉 自摸！" if ok else ""
        print(f"[R{r}] P{pid+1} 出【{best.card}】摸{dr} val={z} {flag}")
        if ok:
            print(f"   → {fmt_hand(game.players[pid])}")
            winner = pid
            break
    else:
        print(f"[R{r}] P{pid+1} 出【{best.card}】  牌堆空")
        break

print()
print("=" * 62)
if winner is not None:
    print(f"  🏆  玩家{winner+1} 和牌！")
else:
    print("  流局")
print(f"  共 {r} 轮 | 弃牌 {len(game.discard_pile)} 张")
print("=" * 62)
