#!/usr/bin/env python3
import game
from game import Card, CardType, WinChecker, ChemicalMahjongGame
from hot_path_engine import HotPathEngine

def fv(v): return f"+{v}" if v >= 0 else str(v)
def sh(hand):
    by = {}
    for c in hand: by.setdefault(c.card_type.value, []).append(str(c))
    _,_,_,a = WinChecker.calculate_optimal_valence(hand)
    parts = " | ".join(f"{k}({len(v)})" for k,v in sorted(by.items()))
    return parts, a

g = ChemicalMahjongGame(4)
g.start_game()
print("="*55)
print(" 化学麻将 · 玩家1(你) vs AI2-4")
print(" 规则：和牌=化合价=0 | 碰=任意家 | 吃=上家+顺子")
print("="*55)
for pid in range(4):
    _,_,_,a = WinChecker.calculate_optimal_valence(g.players[pid])
    tag = "【你】" if pid==0 else f" AI{pid}"
    print(f"{tag} {len(g.players[pid])}张 val={fv(a)}")
print()

ROUND = 0
while True:
    ROUND += 1
    print(f"\n{'='*50}\n第 {ROUND} 回合\n出牌堆：{' '.join(c.name for c in g.discard_pile[-6:])}")
    for pid in range(4):
        hand = g.players[pid]
        is_you = (pid==0)
        if is_you:
            parts, a = sh(hand)
            print(f"\n【你的手牌】 val={fv(a)}  {parts}")
            print(f"选0~{len(hand)-1}或直接打字打牌名：")
            for i,c in enumerate(hand): print(f"  {i}: {c}")
            try: choice = input("\n> ").strip()
            except EOFError: print("退出"); break
            disc = None
            if choice:
                try:
                    idx=int(choice)
                    if 0<=idx<len(hand): disc=hand[idx]
                except ValueError:
                    for c in hand:
                        if c.name==choice or str(c)==choice: disc=c; break
            if not disc: disc=hand[0]
            print(f"你出：{disc}")
        else:
            e=HotPathEngine(g); e.precompute(pid)
            opts=e.get_top(pid,3); disc=opts[0].card if opts else hand[0]
            _,_,_,a=WinChecker.calculate_optimal_valence(hand)
            print(f"\nAI{pid} 出：{disc}  val={fv(a)}")
        g.players[pid].remove(disc); g.discard_pile.append(disc)
        resp=[]
        for o in range(4):
            if o==pid: continue
            ep=g.get_eat_peng_suggestions(o,disc,pid)
            if ep["can_peng"]: resp.append((o,"碰",ep["peng_cards"]))
            elif ep["can_eat"]: resp.append((o,"吃",ep["eat_combos"]))
        if resp:
            for o,act,data in resp:
                if is_you and o==0:
                    print(f"\n  ** 你可以{act}！选择：",end="")
                    if act=="碰":
                        print("0=碰 1=跳过")
                        try: ch=input("  > ").strip()
                        except EOFError: ch=""
                        if ch=="0":
                            mc=data[0]; mg=[c for c in g.players[0] if c==mc]
                            g.players[0].remove(mg[0]); g.players[0].remove(mg[1])
                            g.discard_pile.remove(disc)
                            g.eat_peng_area.setdefault(0,[]).append([mg[0],mg[1],disc])
                            d=g.deck.draw(1)
                            if d: g.players[0].append(d[0])
                            print(f"  碰！摸：{d[0] if d else '无'}")
                    else:
                        for i,cb in enumerate(data[:3]): print(f"  {i}: {'-'.join(x.name for x in cb)}")
                        try: ch=input("  选：").strip()
                        except EOFError: ch=""
                        if ch.isdigit() and int(ch)<len(data):
                            c1,c2,c3=data[int(ch)]
                            g.players[0].remove(c1); g.players[0].remove(c3)
                            g.discard_pile.remove(disc)
                            g.eat_peng_area.setdefault(0,[]).append([c1,c2,c3])
                            d=g.deck.draw(1)
                            if d: g.players[0].append(d[0])
                            print(f"  吃！摸：{d[0] if d else '无'}")
                else:
                    if act=="碰":
                        mc=data[0]; mg=[c for c in g.players[o] if c==mc]
                        g.players[o].remove(mg[0]); g.players[o].remove(mg[1])
                        g.discard_pile.remove(disc)
                        g.eat_peng_area.setdefault(o,[]).append([mg[0],mg[1],disc])
                        d=g.deck.draw(1)
                        if d: g.players[o].append(d[0])
                        print(f"  ⚡ AI{o} 碰！摸：{d[0] if d else '无'}")
                    else:
                        for cb in data:
                            c1,c2,c3=cb
                            ok2,_=WinChecker.check_sequence(c1,c2,c3)
                            if ok2:
                                g.players[o].remove(c1); g.players[o].remove(c3)
                                g.discard_pile.remove(disc)
                                g.eat_peng_area.setdefault(o,[]).append([c1,c2,c3])
                                d=g.deck.draw(1)
                                if d: g.players[o].append(d[0])
                                print(f"  🍜 AI{o} 吃：{c1}-{c2}-{c3}！摸：{d[0] if d else '无'}")
                                break
        drawn=g.deck.draw(1)
        if drawn:
            g.players[pid].append(drawn[0])
            print(f"  ↑ {('你摸' if is_you else f'AI{pid}摸')}：{drawn[0]}")
        else: print("  ⚠️ 牌空")
        ok,msg=WinChecker.check_win(g.players[pid])
        if ok:
            print(f"\n{'='*35}")
            print(f"🎉 {'你' if is_you else f'AI{pid}'} 和牌！{msg}")
            print(f"{'='*35}")
            exit()
        if len(g.deck.cards)==0: print("\n⚠️ 流局"); break
        if is_you:
            parts2,a2=sh(g.players[pid])
            print(f"  → 新手牌 val={fv(a2)}  {parts2}")
