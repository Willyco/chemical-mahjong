#!/usr/bin/env python3
"""化学麻将 - 用户出Ag后的第一轮"""
import sys, os, io
sys.path.insert(0, os.path.dirname(__file__))

old_stdout = sys.stdout; sys.stdout = io.StringIO()
from game import ChemicalMahjongGame, CardType, Card
from hot_path_engine import HotPathEngine
sys.stdout = old_stdout

game = ChemicalMahjongGame(num_players=4)
game.start_game()
e = HotPathEngine(game)
for p in range(4): e.precompute(p)

def fmt(hand):
    g = {}
    for c in hand:
        g.setdefault(c.card_type, []).append(str(c))
    parts = []
    for ct in [CardType.ELEMENT, CardType.ION, CardType.MOLECULE,
               CardType.CONDITION, CardType.STATE]:
        if ct in g:
            parts.append(f"{ct.name}:{' '.join(g[ct])}")
    return " | ".join(parts)

def is_win(hand):
    v, _ = e.win_checker.calculate_optimal_valence(hand)
    has_mol = any(c.card_type == CardType.MOLECULE for c in hand)
    has_cond = any(c.card_type == CardType.CONDITION for c in hand)
    is_waste = has_cond and not has_mol
    return v == 0 and not is_waste, v

def ai_choose(pid):
    opts = e.get_top(pid, 8)
    for o in opts:
        if o.immediate_win or o.win_after_draw:
            return o
    return min(opts, key=lambda x: abs(x.new_valence))

def find_card(hand, name):
    for c in hand:
        if c.name == name:
            return c
    return None

def show_state(pid, drawn=None):
    h = game.players[pid]
    v, _ = e.win_checker.calculate_optimal_valence(h)
    ok, _ = is_win(h)
    if drawn:
        print(f"  → 摸【{drawn}】剩余{len(h)}张 val={v}", end="")
    else:
        print(f"  手牌{len(h)}张 val={v}", end="")
    if ok:
        print(" 🎉 自摸！")
    else:
        print()
    return ok

# ── 第1轮：用户（玩家1/庄家）出Ag ───────────────────────
print("=" * 62)
print("  🀄  化学麻将 · 第1轮  🀄")
print("=" * 62)

print("\n【你的回合】")
ag = find_card(game.players[0], "Ag")
print(f"  出【{ag}】")
game.players[0].remove(ag)
game.discard_pile.append(ag)
for p in range(4): e.invalidate(p)
v0, _ = is_win(game.players[0])
print(f"  剩余13张 val={v0}（庄家首轮不摸牌）")

print("\n【玩家2回合】")
best2 = ai_choose(1)
game.players[1].remove(best2.card)
game.discard_pile.append(best2.card)
for p in range(4): e.invalidate(p)
print(f"  出【{best2.card}】", end="")
if game.deck.cards:
    dr2 = game.deck.draw(1)[0]
    game.players[1].append(dr2)
    e.invalidate(1); e.precompute(1)
    if show_state(1, dr2): print("  🎉🎉 玩家2 自摸！")

print("\n【玩家3回合】")
best3 = ai_choose(2)
game.players[2].remove(best3.card)
game.discard_pile.append(best3.card)
for p in range(4): e.invalidate(p)
print(f"  出【{best3.card}】", end="")
if game.deck.cards:
    dr3 = game.deck.draw(1)[0]
    game.players[2].append(dr3)
    e.invalidate(2); e.precompute(2)
    if show_state(2, dr3): print("  🎉🎉 玩家3 自摸！")

print("\n【玩家4回合】")
best4 = ai_choose(3)
game.players[3].remove(best4.card)
game.discard_pile.append(best4.card)
for p in range(4): e.invalidate(p)
print(f"  出【{best4.card}】", end="")
if game.deck.cards:
    dr4 = game.deck.draw(1)[0]
    game.players[3].append(dr4)
    e.invalidate(3); e.precompute(3)
    if show_state(3, dr4): print("  🎉🎉 玩家4 自摸！")

# ── 第2轮：你的回合 ──────────────────────────────────────
print()
print("=" * 62)
print("  🀄  第2轮 - 你的回合  🀄")
print("=" * 62)

uh = game.players[0]
opts = e.get_top(0, 5)
print(f"\n📋 你当前手牌（{len(uh)}张）")
print(fmt(uh))
print()
print("💡 AI建议 Top5（你决定出哪张）：")
for i, o in enumerate(opts, 1):
    flag = "🎯" if o.immediate_win else ("⏳" if o.win_after_draw else "  ")
    print(f"   {i}. 出【{o.card}】→{o.new_valence} {flag}  {o.reason}")
print(f"\n   弃牌堆: {' '.join(str(c) for c in game.discard_pile)}")

# 保存游戏状态供下一轮使用
import pickle
with open("/tmp/game_state.pkl", "wb") as f:
    pickle.dump({"game": game, "e": e}, f)
print("\n   [状态已保存，输入第2轮选择继续]")
