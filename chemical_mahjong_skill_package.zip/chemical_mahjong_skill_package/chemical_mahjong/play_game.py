"""
化学麻将 - 完整单局游戏
Chemical Mahjong - Complete Single Game
"""

import sys
sys.path.insert(0, '/Users/yehonghao/.qclaw/workspace/chemical_mahjong')

from game import ChemicalMahjongGame, Card, CardType

def play_complete_game():
    """完整的单局游戏，直到有人和牌"""
    
    game = ChemicalMahjongGame(num_players=4)
    game.start_game()
    
    print("\n" + "=" * 80)
    print("【化学麻将 - 完整单局游戏】")
    print("=" * 80)
    
    # 显示初始手牌
    print("\n【初始手牌分配】")
    for i in range(4):
        print(f"\n玩家{i + 1}（{'庄家' if i == 0 else '闲家'}）：")
        hand = game.players[i]
        valence = sum(card.valence for card in hand)
        print(f"  手牌数：{len(hand)}张")
        print(f"  化合价：{valence}")
        print(f"  牌组：{' '.join(str(c) for c in hand)}")
    
    # 游戏主循环
    round_num = 0
    max_rounds = 50  # 最多50轮
    winner = None
    
    print("\n" + "=" * 80)
    print("【游戏进行】")
    print("=" * 80)
    
    while round_num < max_rounds and winner is None:
        round_num += 1
        player_id = (round_num - 1) % 4
        
        print(f"\n【第{round_num}轮】玩家{player_id + 1}出牌")
        print("-" * 80)
        
        # 获取当前玩家的手牌信息
        hand = game.players[player_id]
        valence = sum(card.valence for card in hand)
        
        print(f"玩家{player_id + 1}当前手牌（{len(hand)}张）：")
        print(f"  {' '.join(str(c) for c in hand)}")
        print(f"  化合价总和：{valence}")
        
        # 检查是否已经和牌
        is_win, msg = game.check_win_condition(player_id)
        if is_win:
            print(f"\n✅ 玩家{player_id + 1} {msg}")
            winner = player_id
            break
        
        # 获取 AI 建议
        suggestion = game.get_ai_suggestion(player_id)
        
        if suggestion['is_listening']:
            print(f"  状态：✅ 已听牌！")
        else:
            print(f"  状态：❌ 未听牌，还需调整{abs(suggestion['need_to_discard'])}")
        
        # 选择出牌
        if suggestion['suggestions']:
            discard_card = suggestion['suggestions'][0]['card']
            reason = suggestion['suggestions'][0]['reason']
            
            print(f"\n出牌决策：")
            print(f"  选择出牌：{discard_card}")
            print(f"  原因：{reason}")
            
            game.players[player_id].remove(discard_card)
            game.discard_pile.append(discard_card)
            
            # 检查其他玩家是否可以吃碰
            print(f"\n其他玩家反应：")
            has_action = False
            
            for check_idx in range(1, 4):
                check_player_id = (player_id + check_idx) % 4
                eat_peng = game.get_eat_peng_suggestions(check_player_id, discard_card, discard_player_id=player_id)
                
                if eat_peng['can_eat']:
                    print(f"  玩家{check_player_id + 1}可以吃！")
                    if eat_peng['eat_suggestions']:
                        eat = eat_peng['eat_suggestions'][0]
                        cards_str = " - ".join(str(c) for c in eat['cards'])
                        print(f"    吃法：{cards_str}，化合价变为{eat['new_valence']}")
                    has_action = True
                    break
                elif eat_peng['can_peng']:
                    print(f"  玩家{check_player_id + 1}可以碰！")
                    peng = eat_peng['peng_info']
                    print(f"    碰：{peng['card']} × 3，化合价变为{peng['new_valence']}")
                    has_action = True
                    break
            
            if not has_action:
                print(f"  无人吃碰")
        else:
            print("  无法出牌！")
            break
        
        # 显示当前弃牌堆
        if len(game.discard_pile) <= 10:
            print(f"\n弃牌堆（共{len(game.discard_pile)}张）：")
            print(f"  {' '.join(str(c) for c in game.discard_pile)}")
        else:
            print(f"\n弃牌堆（共{len(game.discard_pile)}张）：")
            recent = game.discard_pile[-10:]
            print(f"  ...{' '.join(str(c) for c in recent)}")
    
    # 游戏结束
    print("\n" + "=" * 80)
    print("【游戏结束】")
    print("=" * 80)
    
    if winner is not None:
        print(f"\n🎉 玩家{winner + 1}和牌！")
        print(f"\n获胜手牌（{len(game.players[winner])}张）：")
        print(f"  {' '.join(str(c) for c in game.players[winner])}")
        print(f"  化合价总和：{sum(card.valence for card in game.players[winner])}")
    else:
        print(f"\n游戏进行了{round_num}轮，未分出胜负")
    
    # 最终统计
    print(f"\n【最终统计】")
    print(f"总轮数：{round_num}")
    print(f"弃牌堆：{len(game.discard_pile)}张")
    
    print(f"\n各玩家最终状态：")
    for i in range(4):
        hand = game.players[i]
        valence = sum(card.valence for card in hand)
        is_listening = valence == 0
        status = "✅ 已听牌" if is_listening else f"❌ 化合价{valence}"
        print(f"  玩家{i + 1}：{len(hand)}张牌，{status}")
    
    print("\n" + "=" * 80)


if __name__ == "__main__":
    play_complete_game()
