#!/usr/bin/env python3
"""
化学麻将 · 玩家对战AI（互动版）
运行方式：python3 interactive_game.py
"""
import game, sys
from game import Card, CardType, WinChecker, ChemicalMahjongGame
from hot_path_engine import HotPathEngine

def fv(v):
    return f"+{v}" if v >= 0 else str(v)

def show_hand(hand):
    by = {}
    for c in hand:
        by.setdefault(c.card_type.value, []).append(str(c))
    parts = " | ".join(f"{k}({len(v)})" for k,v in sorted(by.items()))
    _,_,_,a = WinChecker.calculate_optimal_valence(hand)
    return parts, a

def print_hand(hand, label="手牌"):
    parts, a = show_hand(hand)
    print(f"【{label}】 val={fv(a)}  {parts}")

# ── 初始化 ────────────────────────────────────────────
g = ChemicalMahjongGame(4)
g.start_game()

print("=" * 55)
print("  🎴 化学麻将 · 玩家1(你) vs AI2-4 🎴")
print("  规则：和牌=化合价总和为0 | 碰=任意家 | 吃=上家顺子")
print("=" * 55)

for pid in range(4):
    hand = g.players[pid]
    tag = "【你】" if pid == 0 else f" AI{pid}"
    _,_,_,a = WinChecker.calculate_optimal_valence(hand)
    print(f"{tag} {len(hand)}张 val={fv(a)}")
    if pid == 0:
        print_hand(hand, "你的手牌")

print(f"\n牌堆剩余：{len(g.deck.cards)}张")

ROUND = 0
while True:
    ROUND += 1
    print(f"\n{'='*55}")
    print(f"第 {ROUND} 回合")
    print(f"出牌堆（近）：{' '.join(c.name for c in g.discard_pile[-8:])}")

    for pid in range(4):
        hand = g.players[pid]
        is_you = (pid == 0)

        # ── 出牌阶段 ──────────────────────────────────
        if is_you:
            print_hand(hand, "你的手牌")
            if len(hand) not in (13, 14):
                print(f"  ⚠️ 异常：手牌{len(hand)}张")
            
            # 显示选牌菜单
            card_list = list(enumerate(hand))
            print(f"\n选择出牌（输入序号 0~{len(hand)-1}，或直接打牌名）：")
            for i, c in enumerate(hand):
                _,_,_,av = WinChecker.calculate_optimal_valence([c])
                print(f"  {i}: {c}  (单牌val={fv(av)})")
            
            try:
                choice = input("\n> ").strip()
            except EOFError:
                print("\n游戏退出")
                break
            
            # 尝试解析为数字或牌名
            disc = None
            if choice:
                try:
                    idx = int(choice)
                    if 0 <= idx < len(hand):
                        disc = hand[idx]
                except ValueError:
                    # 按牌名匹配
                    for c in hand:
                        if c.name == choice or str(c) == choice:
                            disc = c
                            break
            
            if disc is None:
                print("  无效输入，自动出第一张")
                disc = hand[0]
            
            print(f"\n你出牌：{disc}")
        else:
            # AI出牌
            e = HotPathEngine(g)
            e.precompute(pid)
            opts = e.get_top(pid, 3)
            disc = opts[0].card if opts else hand[0]
            _,_,_,a = WinChecker.calculate_optimal_valence(hand)
            print(f"\nAI{pid} 出牌：{disc}  (val={fv(a)})")

        # 正式移除
        g.players[pid].remove(disc)
        g.discard_pile.append(disc)

        # ── 吃/碰响应阶段 ──────────────────────────────
        print(f"  └ 弃牌堆 ← {disc}")
        responses = {}
        for other in range(4):
            if other == pid: continue
            ep = g.get_eat_peng_suggestions(other, disc, pid)
            if ep["can_peng"]:
                responses[other] = ("碰", ep["peng_cards"])
            elif ep["can_eat"]:
                responses[other] = ("吃", ep["eat_combos"])

        if responses:
            for other, (action, data) in responses.items():
                if is_you and other == 0:
                    # 玩家需要决定
                    print(f"\n  ⚡ 你可以{action}！")
                    if action == "碰":
                        print(f"  选择：0=碰 | 1=跳过")
                        ch = input("  > ").strip()
                        if ch == "0":
                            mc = data[0]
                            matching = [c for c in g.players[0] if c == mc]
                            g.players[0].remove(matching[0])
                            g.players[0].remove(matching[1])
                            g.discard_pile.remove(disc)
                            g.eat_peng_area.setdefault(0, []).append([matching[0], matching[1], disc])
                            print(f"  → 你碰了！放入吃碰区")
                            d = g.deck.draw(1)
                            if d: g.players[0].append(d[0])
                            print(f"  ↑ 摸牌：{d[0]}")
                        else:
                            print("  跳过碰")
                    else:  # 吃
                        print(f"  可吃组合：")
                        for i, combo in enumerate(data[:3]):
                            print(f"    {i}: {'-'.join(c.name for c in combo)}")
                        ch = input("  选择组合（序号），或直接回车跳过：").strip()
                        if ch.isdigit() and int(ch) < len(data):
                            c1, c2, c3 = data[int(ch)]
                            g.players[0].remove(c1)
                            g.players[0].remove(c3)
                            g.discard_pile.remove(disc)
                            g.eat_peng_area.setdefault(0, []).append([c1, c2, c3])
                            print(f"  → 你吃了！放入吃碰区")
                            d = g.deck.draw(1)
                            if d: g.players[0].append(d[0])
                            print(f"  ↑ 摸牌：{d[0]}")
                        else:
                            print("  跳过吃")
                else:
                    # AI自动碰/吃
                    if action == "碰":
                        mc = data[0]
                        matching = [c for c in g.players[other] if c == mc]
                        g.players[other].remove(matching[0])
                        g.players[other].remove(matching[1])
                        g.discard_pile.remove(disc)
                        g.eat_peng_area.setdefault(other, []).append([matching[0], matching[1], disc])
                        print(f"  ⚡ AI{other} 碰！放入吃碰区")
                        d = g.deck.draw(1)
                        if d: g.players[other].append(d[0])
                    elif action == "吃":
                        for combo in data:
                            c1, c2, c3 = combo
                            ok2, _ = WinChecker.check_sequence(c1, c2, c3)
                            if ok2:
                                g.players[other].remove(c1)
                                g.players[other].remove(c3)
                                g.discard_pile.remove(disc)
                                g.eat_peng_area.setdefault(other, []).append([c1, c2, c3])
                                print(f"  🍜 AI{other} 吃：{c1}-{c2}-{c3}！放入吃碰区")
                                d = g.deck.draw(1)
                                if d: g.players[other].append(d[0])
                                break
        else:
            print(f"  └ 无人可吃/碰")

        # ── 出牌者摸牌 ─────────────────────────────────
        drawn = g.deck.draw(1)
        if drawn:
            g.players[pid].append(drawn[0])
            print(f"  ↑ {('你摸' if is_you else f'AI{pid}摸')}牌：{drawn[0]}")
        else:
            print(f"  ⚠️ 牌堆已空！")

        # ── 和牌检查 ───────────────────────────────────
        ok, msg = WinChecker.check_win(g.players[pid])
        if ok:
            print(f"\n{'='*35}")
            if is_you:
                print(f"🎉🎉 恭喜！你和牌了！🎉🎉")
            else:
                print(f"    AI{pid} 和牌了！")
            print(f"    {msg}")
            print(f"    手牌：{hand_summary(g.players[pid]) if is_you else '(AI手牌)'}")
            print(f"{'='*35}")
            break

        # ── 更新显示 ───────────────────────────────────
        if is_you:
            print_hand(g.players[pid], "你的新手牌")

        if len(g.deck.cards) == 0:
            print("\n⚠️  牌堆耗尽，流局")
            break
