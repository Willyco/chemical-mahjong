"""
化学麻将 - 文字版游戏引擎
Chemical Mahjong - Text-based Game Engine

所有规则数据统一从 rules.json 读取，避免硬编码重复错误。
"""

import json, os, random
from enum import Enum
from typing import List, Dict, Tuple, Set
from dataclasses import dataclass

# ════════════════════════════════════════════════════════════════
# 加载规则数据（顶层，确保所有类都能访问）
# ════════════════════════════════════════════════════════════════
_RULES_PATH = os.path.join(os.path.dirname(__file__), "rules.json")

def _load_rules():
    if os.path.exists(_RULES_PATH):
        with open(_RULES_PATH, encoding="utf-8") as f:
            return json.load(f)
    return None  # 降级：使用类内硬编码

_RULES = _load_rules()

# ════════════════════════════════════════════════════════════════
# 牌的类型
# ════════════════════════════════════════════════════════════════
class CardType(Enum):
    ELEMENT  = "元素"
    ION      = "离子"
    MOLECULE = "分子"
    CONDITION = "条件"
    STATE    = "状态"

# ════════════════════════════════════════════════════════════════
# 牌的数据类
# ════════════════════════════════════════════════════════════════
@dataclass
class Card:
    name: str
    card_type: CardType
    valence: int = 0  # 化合价，0表示无化合价（分子/条件/状态牌）

    def __repr__(self): return f"{self.name}"
    def __eq__(self, other): return self.name == other.name and self.card_type == other.card_type
    def __hash__(self): return hash((self.name, self.card_type))

# ════════════════════════════════════════════════════════════════
# 牌库（从 rules.json 初始化）
# ════════════════════════════════════════════════════════════════
class CardDeck:
    def __init__(self):
        self.cards: List[Card] = []
        self._init_cards()

    def _init_cards(self):
        if _RULES:
            # ── 来自 rules.json ──────────────────────────────────
            for e in _RULES["elements"]:
                for _ in range(e["count"]):
                    self.cards.append(Card(e["name"], CardType.ELEMENT, e["valence_default"]))
            for i in _RULES["ions"]:
                for _ in range(i["count"]):
                    self.cards.append(Card(i["name"], CardType.ION, i["valence"]))
            for m in _RULES["molecules"]:
                for _ in range(m["count"]):
                    self.cards.append(Card(m["name"], CardType.MOLECULE, 0))
            for c in _RULES["conditions"]:
                for _ in range(c["count"]):
                    self.cards.append(Card(c["name"], CardType.CONDITION, 0))
            for s in _RULES["states"]:
                for _ in range(s["count"]):
                    self.cards.append(Card(s["name"], CardType.STATE, 0))
        else:
            # ── 降级硬编码（rules.json 不存在时）────────────────
            elements = [
                ("Na",1),("Mg",2),("Al",3),("K",1),("Ca",2),("Fe",2),
                ("Cu",2),("Zn",2),("Ba",2),("Ag",1),("H",1),("P",5),
                ("S",-2),("Cl",-1),("C",4),("N",-3),("O",-2)
            ]
            for n,v in elements:
                for _ in range(4): self.cards.append(Card(n, CardType.ELEMENT, v))
            ions = [("NO3⁻¹",-1),("OH⁻¹",-1),("NH4⁺¹",1),
                    ("PO4⁻³",-3),("CO3⁻²",-2),("SO4⁻²",-2)]
            for n,v in ions:
                for _ in range(4): self.cards.append(Card(n, CardType.ION, v))
            for m in ["KMnO4","K2MnO4","MnO2","CO2","H2O","H2","O2","Cl2"]:
                for _ in range(4): self.cards.append(Card(m, CardType.MOLECULE, 0))
            for c in ["点燃","加热","高温","电解"]:
                for _ in range(4): self.cards.append(Card(c, CardType.CONDITION, 0))
            for s in ["气体","沉淀"]:
                for _ in range(2): self.cards.append(Card(s, CardType.STATE, 0))

        total = len(self.cards)
        if _RULES:
            expected = _RULES["metadata"]["total_cards"]
        else:
            expected = 144
        assert total == expected, f"牌库数量错误：{total} ≠ {expected}"

    def shuffle(self): random.shuffle(self.cards)

    def draw(self, count: int) -> List[Card]:
        drawn = self.cards[:count]
        self.cards = self.cards[count:]
        return drawn

# ════════════════════════════════════════════════════════════════
# 和牌判断（从 rules.json 读取 ELEMENT_ORDER 和化合价选项）
# ════════════════════════════════════════════════════════════════
class WinChecker:
    # ── 从 rules.json 加载（降级为硬编码）───────────────────────
    if _RULES:
        ELEMENT_ORDER = _RULES["element_order"]
        ELEMENT_ATOMIC = {e["name"]: e["atomic_number"] for e in _RULES["elements"]}
        ELEMENT_VALENCES = {
            e["name"]: e["valence_options"] for e in _RULES["elements"]
        }
        VALID_COMPOUNDS = _RULES["valid_compounds"]
    else:
        ELEMENT_ORDER = [
            "H","C","N","O","P","S","Cl",
            "Na","Mg","Al","K","Ca","Fe","Cu","Zn","Ba","Ag"
        ]
        ELEMENT_ATOMIC = {
            "H":1,"C":6,"N":7,"O":8,"P":15,"S":16,"Cl":17,
            "Na":11,"Mg":12,"Al":13,"K":19,"Ca":20,
            "Fe":26,"Cu":29,"Zn":30,"Ba":56,"Ag":47,
        }
        ELEMENT_VALENCES = {
            "Na":[1],"Mg":[2],"Al":[3],"K":[1],"Ca":[2],
            "Fe":[2,3],"Cu":[1,2],"Zn":[2],"Ba":[2],"Ag":[1],
            "H":[1,-1],"P":[-3,3,5],"S":[-2,2,4,6],
            "Cl":[-1,1,3,5,7],"C":[-4,2,4],"N":[-3,1,2,3,4,5],"O":[-2],
        }
        VALID_COMPOUNDS = {}

    # ── 化合物生成（辅助）──────────────────────────────────────
    @staticmethod
    def _form_compound(c1: Card, c2: Card) -> str:
        def strip(s):
            return s.replace("⁺","").replace("⁻","").replace("¹","").replace("²","").replace("³","")
        from math import gcd
        v1, v2 = abs(c1.valence), abs(c2.valence)
        e1, e2 = strip(c1.name), strip(c2.name)
        if v1 == v2: return f"{e1}{e2}"
        lcm = v1*v2 // gcd(v1, v2)
        n1, n2 = lcm//v1, lcm//v2
        return f"{e1}{n1}{e2}{n2}" if n1>1 or n2>1 else f"{e1}{e2}"

    # ── 成对子检查 ───────────────────────────────────────────
    @staticmethod
    def check_pair(c1: Card, c2: Card) -> Tuple[bool, str]:
        if c1.valence == 0 or c2.valence == 0:
            return False, "分子/条件/状态牌不能成对子"
        if abs(c1.valence) != abs(c2.valence):
            return False, f"化合价数值不等：{abs(c1.valence)}≠{abs(c2.valence)}"
        if c1.valence * c2.valence >= 0:
            return False, f"化合价同号：{c1.valence} 与 {c2.valence}"
        return True, f"可成对子：{c1} + {c2}"

    # ── 成顺子检查（仅元素牌，周期表连续）──────────────────────
    @staticmethod
    def check_sequence(c1: Card, c2: Card, c3: Card) -> Tuple[bool, str]:
        for c in (c1, c2, c3):
            if c.card_type != CardType.ELEMENT:
                return False, "顺子必须全为元素牌"
        try:
            atomic = sorted(WinChecker.ELEMENT_ATOMIC[c.name] for c in (c1, c2, c3))
        except KeyError:
            return False, "含未知元素"
        if atomic[1]==atomic[0]+1 and atomic[2]==atomic[1]+1:
            name_map = {v: k for k, v in WinChecker.ELEMENT_ATOMIC.items()}
            return True, f"可成顺子：{name_map[atomic[0]]}-{name_map[atomic[1]]}-{name_map[atomic[2]]}"
        return False, f"原子序数不连续：{atomic[0]}-{atomic[1]}-{atomic[2]}"

    # ── 成刻子检查（三张完全相同）──────────────────────────────
    @staticmethod
    def check_triplet(c1: Card, c2: Card, c3: Card) -> Tuple[bool, str]:
        if c1 == c2 == c3:
            return True, f"可成刻子：{c1} × 3"
        return False, f"三张牌不相同：{c1.name},{c2.name},{c3.name}"

    # ── 和牌主检查 ───────────────────────────────────────────
    @staticmethod
    def check_win(hand: List[Card]) -> Tuple[bool, str]:
        """和牌条件：14张 + 化合价总和为0 + 非纯废牌"""
        if len(hand) != 14:
            return False, f"手牌{len(hand)}张，需14张"
        total, _, _, actual = WinChecker.calculate_optimal_valence(hand)
        if actual != 0:
            return False, f"化合价总和为{actual}，未和牌"
        # 废牌检查：有条件/状态牌时必须搭配分子牌，否则为废牌
        has_mol = any(c.card_type == CardType.MOLECULE for c in hand)
        has_cond_or_state = any(
            c.card_type in (CardType.CONDITION, CardType.STATE) for c in hand
        )
        if has_cond_or_state and not has_mol:
            return False, "有条件/状态牌但无分子牌，属废牌，不能和牌"
        return True, "和牌！化合价总和为0"

    # ── 化合价优化枚举（多化合价元素枚举所有可能）──────────────
    @staticmethod
    def calculate_optimal_valence(hand: List[Card]) -> Tuple[int, Dict, int, int]:
        """返回：(min_valence, best_combo, other_valence, actual_valence)"""
        from itertools import product

        element_cards = [c for c in hand if c.card_type == CardType.ELEMENT]
        other_cards   = [c for c in hand if c.card_type != CardType.ELEMENT]
        other_valence = sum(c.valence for c in other_cards)

        if not element_cards:
            actual = other_valence
            return actual, {}, other_valence, actual

        opts = [
            WinChecker.ELEMENT_VALENCES.get(c.name, [c.valence])
            for c in element_cards
        ]

        best_v = float("inf")
        best_combo = {}

        for combo in product(*opts):
            total = sum(combo) + other_valence
            if abs(total) < abs(best_v):
                best_v = total
                best_combo = {element_cards[i].name: combo[i]
                              for i in range(len(element_cards))}

        actual = sum(c.valence for c in element_cards) + other_valence
        return int(best_v), best_combo, other_valence, int(actual)

# ════════════════════════════════════════════════════════════════
# 游戏主类
# ════════════════════════════════════════════════════════════════
class ChemicalMahjongGame:
    def __init__(self, num_players: int = 4):
        self.num_players  = num_players
        self.deck          = CardDeck()
        self.players       : List[List[Card]] = [[] for _ in range(num_players)]
        self.discard_pile  : List[Card]      = []
        self.current_player = 0
        self.win_checker   = WinChecker()

    def start_game(self):
        print("=" * 50)
        print("化学麻将 - 文字版游戏")
        print("=" * 50)
        self.deck.shuffle()
        for i in range(self.num_players):
            self.players[i] = sorted(
                self.deck.draw(14 if i == 0 else 13),
                key=lambda c: (c.card_type.value, WinChecker.ELEMENT_ATOMIC.get(c.name, 0), c.name)
            )
        print(f"\n游戏开始！共{self.num_players}人")
        print(f"庄家：玩家1（14张牌）")
        print(f"闲家：玩家2-4（各13张牌）\n")
        self.show_player_hand(0)

    def show_player_hand(self, player_id: int):
        hand = self.players[player_id]
        print(f"\n玩家{player_id + 1}的手牌（共{len(hand)}张）：")
        by_type = {}
        for card in hand:
            by_type.setdefault(card.card_type, []).append(card)
        for ct in CardType:
            if ct in by_type:
                print(f"  {ct.value}：" + " ".join(str(c) for c in by_type[ct]))
        total = sum(card.valence for card in hand)
        print(f"  化合价总和：{total}")

    def check_win_condition(self, player_id: int) -> Tuple[bool, str]:
        return self.win_checker.check_win(self.players[player_id])

    def get_ai_suggestion(self, player_id: int) -> Dict:
        hand = self.players[player_id]
        total = sum(card.valence for card in hand)
        suggestions = []
        for card in hand:
            suggestions.append({
                "card": card,
                "new_valence": total - card.valence,
                "reason": f"出{card}({card.valence:+d})→{total - card.valence:+d}",
                "priority": 10 if abs(total - card.valence) < abs(total) else 1,
            })
        suggestions.sort(key=lambda x: x["priority"], reverse=True)
        return {
            "current_valence": total,
            "target_valence": 0,
            "suggestions": suggestions,
        }

    def show_ai_suggestion(self, player_id: int):
        info = self.get_ai_suggestion(player_id)
        print("\nAI 出牌建议：")
        print(f"  当前化合价：{info['current_valence']}，目标：{info['target_valence']}")
        for s in info["suggestions"][:5]:
            print(f"  出【{s['card']}】→ {s['new_valence']:+d}  {s['reason']}")

    def get_eat_peng_suggestions(self, player_id: int,
                                  discard_card: Card,
                                  discard_player_id: int) -> Dict:
        hand = self.players[player_id]
        is_upstream = (discard_player_id == (player_id - 1) % self.num_players)
        result = {"can_eat": False, "can_peng": False, "peng_cards": []}

        # ── 碰：任意家出牌都可碰，手握两张即可 ─────────────────
        matching = [c for c in hand if c == discard_card]
        if len(matching) >= 2:
            result["can_peng"] = True
            result["peng_cards"] = [discard_card, discard_card]

        # ── 吃：仅上家出牌可吃 ────────────────────────────────
        if not is_upstream:
            return result
        element_hand = sorted(
            [c for c in hand if c.card_type == CardType.ELEMENT],
            key=lambda c: WinChecker.ELEMENT_ATOMIC.get(c.name, 0)
        )
        try:
            discard_pos = WinChecker.ELEMENT_ATOMIC[discard_card.name]
        except KeyError:
            return result
        if discard_card.card_type == CardType.ELEMENT and element_hand:
            eat_combos = []
            for i, elem in enumerate(element_hand):
                for j, elem2 in enumerate(element_hand):
                    if i >= j:
                        continue
                    try:
                        pi = WinChecker.ELEMENT_ATOMIC[elem.name]
                        pj = WinChecker.ELEMENT_ATOMIC[elem2.name]
                    except KeyError:
                        continue
                    sorted_pos = sorted([pi, discard_pos, pj])
                    if sorted_pos[1] == sorted_pos[0] + 1 and sorted_pos[2] == sorted_pos[1] + 1:
                        eat_combos.append((elem, discard_card, elem2))
            if eat_combos:
                result["can_eat"] = True
                result["eat_combos"] = eat_combos
        return result

    def show_eat_peng_suggestions(self, player_id: int,
                                   discard_card: Card,
                                   discard_player_id: int):
        ep = self.get_eat_peng_suggestions(player_id, discard_card, discard_player_id)
        print(f"\n玩家{player_id+1} 对 【{discard_card}】 的建议：")
        if ep["can_eat"]:
            for combo in ep.get("eat_combos", []):
                print(f"  可吃：{' '.join(str(c) for c in combo)}")
        else:
            print(f"  不可吃（仅上家可吃）")
        if ep["can_peng"]:
            print(f"  可碰！")
        else:
            print(f"  不可碰")

# ════════════════════════════════════════════════════════════════
# 调试入口
# ════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    game = ChemicalMahjongGame(num_players=4)
    game.start_game()
    game.show_ai_suggestion(0)
