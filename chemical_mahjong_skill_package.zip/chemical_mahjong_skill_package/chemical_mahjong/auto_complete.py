"""
化学麻将 - 完整自动模拟（直到有人和牌）
Chemical Mahjong - Complete Auto Simulation Until Someone Wins
"""

import sys
sys.path.insert(0, '/Users/yehonghao/.qclaw/workspace/chemical_mahjong')

from game import ChemicalMahjongGame, Card, CardType

class AutoMahjongGame(ChemicalMahjongGame):
    """自动麻将游戏，支持吃碰区"""
    
    def __init__(self, num_players=4):
        super().__init__(num_players)
        # 每个玩家的吃碰区（存放吃碰的牌组）
        self.eat_peng_area = [[] for _ in range(num_players)]
    
    def get_total_hand_size(self, player_id):
        """获取玩家的总牌数（手牌 + 吃碰区）"""
        hand_size = len(self.players[player_id])
        peng_size = sum(len(group) for group in self.eat_peng_area[player_id])
        return hand_size + peng_size
    
    def check_win_with_eat_peng(self, player_id):
        """检查是否和牌（考虑吃碰区）"""
        hand = self.players[player_id]
        eat_peng = self.eat_peng_area[player_id]
        
        # 手牌 + 吃碰区的总化合价
        total_valence = sum(card.valence for card in hand)
        total_valence += sum(sum(card.valence for card in group) for group in eat_peng)
        
        # 总牌数应该是14张（或13张）
        total_cards = len(hand) + sum(len(group) for group in eat_peng)
        
        if total_valence == 0 and total_cards == 14:
            return True, "和牌！化合价总和为0，总牌数14张"
        elif total_valence == 0 and total_cards == 13:
            return True, "和牌！化合价总和为0，总牌数13张"
        else:
            return False, f"未和牌（化合价{total_valence}，总牌数{total_cards}）"


def auto_play_complete_game():
    """自动完整模拟一局游戏"""
    
    game = AutoMahjongGame(num_players=4)
    game.start_game()
    
    print("\n" + "=" * 80)
    print("【化学麻将 - 完整自动模拟】")
    print("=" * 80)
    
    # 显示初始手牌
    print("\n【初始手牌分配】")
    for i in range(4):
        hand = game.players[i]
        valence = sum(card.valence for card in hand)
        print(f"玩家{i + 1}（{'庄家' if i == 0 else '闲家'}）：{len(hand)}张，化合价{valence}")
    
    round_num = 0
    max_rounds = 200
    winner = None
    
    print("\n" + "=" * 80)
    print("【游戏进行】")
    print("=" * 80)
    
    while round_num < max_rounds and winner is None:
        round_num += 1
        player_id = (round_num - 1) % 4
        
        print(f"\n【第{round_num}轮】玩家{player_id + 1}出牌")
        
        # 获取当前玩家的手牌信息
        hand = game.players[player_id]
        valence = sum(card.valence for card in hand)
        
        print(f"  手牌数：{len(hand)}，化合价：{valence}")
        
        # 检查是否已经和牌
        is_win, msg = game.check_win_with_eat_peng(player_id)
        if is_win:
            print(f"  ✅ {msg}")
            winner = player_id
            break
        
        # 如果手牌为空，游戏结束（异常情况）
        if len(hand) == 0:
            print(f"  ❌ 手牌为空，游戏异常结束")
            break
        
        # 获取 AI 建议
        suggestion = game.get_ai_suggestion(player_id)
        
        if suggestion['suggestions']:
            discard_card = suggestion['suggestions'][0]['card']
            
            print(f"  出牌：{discard_card}")
            
            game.players[player_id].remove(discard_card)
            game.discard_pile.append(discard_card)
            
            # 检查其他玩家是否可以吃碰
            has_action = False
            
            for check_idx in range(1, 4):
                check_player_id = (player_id + check_idx) % 4
                eat_peng = game.get_eat_peng_suggestions(check_player_id, discard_card, discard_player_id=player_id)
                
                if eat_peng['can_eat']:
                    print(f"  → 玩家{check_player_id + 1}吃牌")
                    has_action = True
                    break
                elif eat_peng['can_peng']:
                    print(f"  → 玩家{check_player_id + 1}碰牌")
                    has_action = True
                    break
            
            if not has_action:
                print(f"  → 无人吃碰")
            
            # 摸牌（从牌库中摸一张）
            if len(game.deck.cards) > 0:
                drawn_card = game.deck.draw(1)[0]
                game.players[player_id].append(drawn_card)
                print(f"  摸牌：{drawn_card}")
            else:
                print(f"  ❌ 牌库已空，游戏结束")
                break
        else:
            print("  无法出牌！")
            break
    
    # 游戏结束
    print("\n" + "=" * 80)
    print("【游戏结束】")
    print("=" * 80)
    
    if winner is not None:
        print(f"\n🎉 玩家{winner + 1}和牌！")
        print(f"\n获胜玩家的最终手牌数：{len(game.players[winner])}张")
        print(f"总轮数：{round_num}轮")
    else:
        print(f"\n游戏进行了{round_num}轮，未分出胜负")
    
    print(f"\n弃牌堆总数：{len(game.discard_pile)}张")
    print(f"牌库剩余：{len(game.deck.cards)}张")
    
    print("\n" + "=" * 80)
    return game, winner, round_num


if __name__ == "__main__":
    game, winner, round_num = auto_play_complete_game()
