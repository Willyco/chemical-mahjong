#!/usr/bin/env python3
"""化学麻将 - 交互式对战版（你 vs 3个AI）"""
import sys, os, io
sys.path.insert(0, os.path.dirname(__file__))

# 抑制游戏引擎的启动banner
old_stdout = sys.stdout
sys.stdout = io.StringIO()
from game import ChemicalMahjongGame, CardType
from hot_path_engine import HotPathEngine
sys.stdout = old_stdout

# ── 初始化 ──────────────────────────────────────────
game = ChemicalMahjongGame(num_players=4)
game.start_game()
e = HotPathEngine(game)
for p in range(4): e.precompute(p)

# ── 工具函数 ────────────────────────────────────────
def fmt(hand, detail=False):
    g = {}
    for c in hand:
        g.setdefault(c.card_type, []).append(str(c))
    if not detail:
        parts = []
        for ct in [CardType.ELEMENT, CardType.ION, CardType.MOLECULE,
                   CardType.CONDITION, CardType.STATE]:
            if ct in g:
                parts.append(f"{ct.name}:{' '.join(g[ct])}")
        return " | ".join(parts)
    else:
        lines = []
        for ct in [CardType.ELEMENT, CardType.ION, CardType.MOLECULE,
                   CardType.CONDITION, CardType.STATE]:
            if ct in g:
                lines.append(f"  [{ct.name}] {' '.join(g[ct])}")
        return "\n".join(lines)

def is_win(hand):
    v, _ = e.win_checker.calculate_optimal_valence(hand)
    has_mol = any(c.card_type == CardType.MOLECULE for c in hand)
    has_cond = any(c.card_type == CardType.CONDITION for c in hand)
    is_waste = has_cond and not has_mol
    return v == 0 and not is_waste, v

def ai_discard(pid):
    """AI决定出哪张牌"""
    opts = e.get_top(pid, 5)
    # 按优先级选：立即和牌 > 摸牌后和牌 > 偏离最少
    for o in opts:
        if not o.immediate_win and not o.win_after_draw:
            # 选偏离最小的
            best = min(opts, key=lambda x: abs(x.new_valence) if not x.immediate_win else 0)
            return best.card, best.new_valence, best.reason
    return opts[0].card, opts[0].new_valence, opts[0].reason

# ── 打印初始状态 ─────────────────────────────────────
print("=" * 62)
print("  🀄  化学麻将 · 你(玩家1) vs AI  🀄")
print("=" * 62)

dh = game.players[0]
_, init_v = is_win(dh)
print(f"\n📋 你的初始手牌（共14张）当前化合价={init_v}")
print(fmt(dh, detail=True))

print("\n💡 AI建议 Top5（你决定出哪张）：")
all_opts = e.get_top(0, 5)
for i, o in enumerate(all_opts, 1):
    flag = "🎯" if o.immediate_win else ("⏳" if o.win_after_draw else "  ")
    print(f"   {i}. 出【{o.card}】→{o.new_valence} {flag}  {o.reason}")

print(f"\n   弃牌堆: {'(空)' if not game.discard_pile else ' '.join(str(c) for c in game.discard_pile)}")
print("=" * 62)
