# 🧪 化学麻将 Skill 包

## 包含内容

```
chemical_mahjong_skill_package/
├── skills/
│   ├── 化学麻将游戏/     # 主游戏 skill
│   └── 化学麻将牌组/     # 牌组记录 skill
└── chemical_mahjong/     # 游戏引擎代码
    ├── game.py           # 核心游戏逻辑
    ├── hot_path_engine.py # AI 热路预计算引擎
    ├── rules.json        # 游戏规则
    └── ...
```

## 安装方法

### 方法1：放到 OpenClaw skills 目录

将 `skills` 文件夹复制到你的 OpenClaw skills 目录：

```bash
cp -r skills/化学麻将游戏 ~/.openclaw/workspace/skills/
cp -r skills/化学麻将牌组 ~/.openclaw/workspace/skills/
```

### 方法2：作为独立 Python 项目使用

```bash
cd chemical_mahjong
python play.py
```

## 触发词

- "开始化学麻将游戏"
- "开始麻将游戏"  
- "化学麻将"
- "麻将"

## 项目结构

| 文件 | 说明 |
|------|------|
| game.py | 核心游戏逻辑（和牌判定、吃碰杠牌） |
| hot_path_engine.py | AI 热路预计算引擎（性能优化） |
| rules.json | 完整规则定义 |
| interactive_game.py | 交互式游戏界面 |

## 版本信息

- 热路预计算引擎 v3: 0.08ms/次查询（树莓派达标）
- 支持7种和牌牌型判定
- 144张牌标准牌堆
